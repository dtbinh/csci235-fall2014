package edu.hendrix.lmsl;

import java.util.EnumMap;

public class EnumHistogram<T extends Enum<T>> extends SemiAbstractHistogram<T,EnumMap<T,Integer>> {
	public EnumHistogram(Class<T> enumType) {
		super(new EnumMap<T,Integer>(enumType));
	}
}
