package edu.hendrix.lmsl;

public interface ModeNameInterface {
	public boolean continuePrevious();
}
