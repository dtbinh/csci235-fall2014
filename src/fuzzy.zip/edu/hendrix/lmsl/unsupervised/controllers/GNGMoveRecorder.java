package edu.hendrix.lmsl.unsupervised.controllers;

import java.io.IOException;
import java.util.LinkedHashMap;

import lejos.hardware.Button;
import lejos.hardware.Key;
import edu.hendrix.ev3webcam.Webcam;
import edu.hendrix.img.IntImage;
import edu.hendrix.lmsl.storage.GNGStorage;

public class GNGMoveRecorder extends GNGController {
	public static void main(String[] args) {
		new GNGMoveRecorder().runController();
	}
	
	private LinkedHashMap<Key,Flag> key2Flag;
	
	protected GNGNodeMoves<Flag> makeGNG() {
		YesNoChooser useOld = new YesNoChooser("Use existing GNG?", false);
		useOld.choose();
		if (useOld.isYes()) {
			GNGChooser getOld = new GNGChooser();
			getOld.choose(GNGStorage.getEV3Storage(Flag.class));
			if (getOld.gngIsSelected()) {
				return getOld.getSelectedGNG();
			}
		}
		
		return super.makeGNG();
	}
	
	public GNGMoveRecorder() {
		super();
		key2Flag = new LinkedHashMap<Key,Flag>();		
		key2Flag.put(Button.UP, Flag.FORWARD);
		key2Flag.put(Button.DOWN, Flag.BACK);
		key2Flag.put(Button.LEFT, Flag.LEFT);
		key2Flag.put(Button.RIGHT, Flag.RIGHT);
		key2Flag.put(Button.ENTER, Flag.STOP);
		key2Flag.put(Button.ESCAPE, Flag.STOP);
	}
	
	public void runController() {
		try {
			Webcam.start(176, 144);
			Flag previous = Flag.STOP;
			while (!Button.ESCAPE.isDown()) {
				IntImage img = GNGController.grabGNGImage(true);
				Key currentKey = getCurrentKey();
				if (currentKey != null) {
					Flag currentFlag = key2Flag.containsKey(currentKey) ? key2Flag.get(currentKey) : previous;
					if (currentFlag != Flag.STOP) {
						updateGNG(currentFlag, img);
					}
					performCurrentAction(currentKey);
					previous = currentFlag;
				}
			}
			close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
			System.out.println("Driver exception: " + ioe.getMessage());
		}
	}
}
