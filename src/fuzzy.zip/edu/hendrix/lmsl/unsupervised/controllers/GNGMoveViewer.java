package edu.hendrix.lmsl.unsupervised.controllers;

import java.io.IOException;
import java.util.ArrayList;

import edu.hendrix.lmsl.storage.GNGStorage;
import lejos.hardware.Button;
import lejos.hardware.lcd.LCD;

public class GNGMoveViewer {
	private GNGStorage<Flag> storage;
	private GNGNodeMoves<Flag> gng;
	private boolean buttonsEnabled, selectionChanged, gngChanged, gngChanging;
	private int node;
	private Flag tentativeChange;
	
	public GNGMoveViewer() {
		storage = GNGStorage.getEV3Storage(Flag.class);
	}
	
	public void run() {
		GNGChooser chooser = new GNGChooser();
		chooser.choose(storage);
		if (chooser.gngIsSelected()) {
			gng = chooser.getSelectedGNG();
			viewEditGNG();
			if (gngChanged) {
				try {
					LCD.clear();
					LCD.drawString("Saving...", 0, 0);
					storage.save(gng);
				} catch (IOException e) {
					e.printStackTrace();
					LCD.clear();
					LCD.drawString("Can't save edited GNG", 0, 0);
				}
			}
			System.out.println("Exiting");
		}
	}

	public static void main(String[] args) {
		new GNGMoveViewer().run();
	}
	
	private void viewEditGNG() {
		ArrayList<Integer> nodeNums = new ArrayList<Integer>(gng.getAllNodeNums());
		node = 0;
		selectionChanged = buttonsEnabled = true;
		gngChanged = gngChanging = false;
		while (!Button.ESCAPE.isDown()) {
			if (buttonsEnabled) {
				selectNode(nodeNums.get(node));
			} else if (allButtonsUp()) {
				buttonsEnabled = true;
			} 
			if (selectionChanged) {
				viewNewNode(nodeNums.get(node));
			}
		}
	}
	
	public static boolean allButtonsUp() {
		return (Button.LEFT.isUp() && Button.RIGHT.isUp() && Button.UP.isUp() && Button.DOWN.isUp() && Button.ENTER.isUp() && Button.ESCAPE.isUp());
	}
	
	private void selectNode(int realNode) {
		if (Button.LEFT.isDown()) {
			node = node - 1;
			if (node < 0) {node += gng.numNodes();}
			selectionChanged = true;
		}
		if (Button.RIGHT.isDown()) {
			node = (node + 1) % gng.numNodes();
			selectionChanged = true;
		}
		
		if (Button.UP.isDown()) {
			if (tentativeChange == null) {
				tentativeChange = Flag.values()[0];
			} else {
				int i = 0;
				while (tentativeChange != Flag.values()[i]) {
					i += 1;
				}
				if (i < Flag.values().length - 1) {
					tentativeChange = Flag.values()[i+1];
				} else {
					tentativeChange = null;
				}
			}
			viewNode(realNode);
		}
		
		if (Button.DOWN.isDown()) {
			if (tentativeChange == null) {
				tentativeChange = Flag.values()[Flag.values().length - 1];
			} else {
				int i = 0;
				while (tentativeChange != Flag.values()[i]) {
					i += 1;
				}
				if (i > 0) {
					tentativeChange = Flag.values()[i-1];
				} else {
					tentativeChange = null;
				}
			}
			viewNode(realNode);
		}
		
		if (Button.ENTER.isDown() && gngChanging) {
			gngChanging = false;
			gng.forceMoveChange(realNode, tentativeChange);
			gngChanged = true;
			viewNewNode(realNode);
		}
	}
	
	private void viewNewNode(int realNode) {
		selectionChanged = false;
		tentativeChange = gng.getMoveFor(realNode);
		viewNode(realNode);
	}
	
	private void viewNode(int realNode) {
		gngChanging = (tentativeChange != gng.getMoveFor(realNode));
		LCD.clearDisplay();
		LCD.drawString("Node:" + realNode, 0, 0);
		displayMove(gng.getMoveFor(realNode), 1);
		if (gngChanging) {
			displayMove(tentativeChange, 2);
		}
		gng.get(realNode).displayLCD(50, 50);
		buttonsEnabled = false;
	}
	
	private void displayMove(Flag move, int line) {
		LCD.drawString(move == null ? "No move" : move.toString(), 0, line);
	}
}
