package edu.hendrix.lmsl.unsupervised.controllers;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import edu.hendrix.img.IntImage;
import edu.hendrix.lmsl.Histogram;
import edu.hendrix.lmsl.unsupervised.IntImageGas;
import edu.hendrix.lmsl.unsupervised.funcs.Euclidean;

public class GNGNodeMoves<F extends Enum<F>> {
	private IntImageGas gng;
	private Map<Integer,F> node2move;
	private Histogram<Integer> node2hits;
	
	private final static String DELIMETER = "Z";
	
	private GNGNodeMoves() {
		node2move = new TreeMap<Integer,F>();
		node2hits = new Histogram<Integer>();
	}
	
	public GNGNodeMoves(IntImageGas gng) {
		this();
		this.gng = new IntImageGas(gng);
	}
	
	public GNGNodeMoves(int lambda, double k) {
		this();
		gng = new IntImageGas(new Euclidean(), lambda, k);
	}
	
	public GNGNodeMoves(Class<F> flagType, String s) {
		this();
		s = s.replace("\r", "");
		String[] parts = s.split(DELIMETER);
		this.gng = new IntImageGas(parts[0].trim());
		
		String[] lines = parts[1].split("\n");
		for (String line: lines) {
			if (line.contains(":")) {
				String[] pair = line.split(":");
				int category = Integer.parseInt(pair[0]);
				F move = Enum.valueOf(flagType, pair[1]);
				this.node2move.put(category, move);
				int count = Integer.parseInt(pair[2]);
				this.node2hits.setCountFor(category, count);
			}
		}
	}
	
	public int numNodes() {return gng.numNodes();}
	
	public int getLowestLabel() {
		return gng.getLowestCategoryNumber();
	}
	
	public void update(F move, IntImage img) {
		gng.trainOnce(img);
		if (gng.hasMostRecentWinner()) {
			int winner = gng.getMostRecentCategory();
			node2hits.bump(winner);
			if (hasMoveFor(winner)) {
				if (!getMoveFor(winner).equals(move)) {
					addMoveFor(gng.forceSpecificNode(winner, img), move);
				}
			} else {
				addMoveFor(winner, move);
			}
		}
	}
	
	public void forceMoveChange(int node, F newMove) {
		if (newMove == null) {
			gng.removeSafetyFrom(node);
			node2move.remove(node);
		} else {
			addMoveFor(node, newMove);
		}
	}
	
	private void addMoveFor(int node, F m) {
		node2move.put(node, m);
		gng.makeSafe(node);
	}
	
	public boolean hasMoveFor(int node) {
		return node2move.containsKey(node);
	}
	
	public F getMoveFor(int node) {
		return node2move.get(node);
	}
	
	public void purgeMoveFreeNodes() {
		for (int node: gng.getAllCategories()) {
			if (!hasMoveFor(node)) {
				gng.deleteNode(node);
			}
		}
	}
	
	public int getHitCountFor(int node) {
		return node2hits.getCountFor(node);
	}
	
	public int getNodeFor(IntImage input) {
		return gng.getCategoryFor(gng.bestMatchFor(input));
	}
	
	public boolean hasNode(int node) {
		return gng.hasCategory(node);
	}
	
	public IntImage get(int node) {
		return gng.get(node);
	}
	
	public ArrayList<Integer> getNeighborsOf(int node) {
		return gng.getNeighborsOf(node);
	}
	
	public Set<Integer> getAllNodeNums() {
		return gng.getAllCategories();
	}
	
	public Iterable<IntImageGas.Neuron> allNeighborsOf(IntImageGas.Neuron node) {
		return gng.allNeighborsOf(node);
	}
	
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder(gng.toString());
		result.append(DELIMETER);
		result.append('\n');
		for (Map.Entry<Integer,F> n: node2move.entrySet()) {
			if (gng.hasCategory(n.getKey())) {
				result.append(n.getKey());
				result.append(':');
				result.append(n.getValue());
				result.append(':');
				result.append(node2hits.getCountFor(n.getKey()));
				result.append('\n');
			}
		}
		return result.toString();
	}
	
	@Override
	public boolean equals(Object other) {
		// Terrible, but easy
		return toString().equals(other.toString());
	}
	
	@Override
	public int hashCode() {return toString().hashCode();}
	
	public void toFile(File f) throws IOException {
		PrintWriter pw = new PrintWriter(new FileWriter(f));
		pw.print(toString());
		pw.close();	
	}
	
	public static <F extends Enum<F>> GNGNodeMoves<F> fromFile(Class<F> flagType, File f) throws FileNotFoundException {
		Scanner scanner = new Scanner(f);
		GNGNodeMoves<F> result = new GNGNodeMoves<F>(flagType, scanner.useDelimiter("\\A").next());
		scanner.close();
		return result;
	}
		
	public GNGNodeMoves<F> includesMovesOnly(Class<F> flagType) {
		GNGNodeMoves<F> result = new GNGNodeMoves<F>(flagType, this.toString());
		for (int node: getAllNodeNums()) {
			if (!hasMoveFor(node)) {
				result.gng.deleteNode(node);
			}
		}
		return result;
	}
	
	public IntImageGas getGNGCopy() {
		return new IntImageGas(gng);
	}
}
