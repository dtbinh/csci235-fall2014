package edu.hendrix.lmsl.fuzzy.demos.demo1;

public enum FlagName {
	CLEAR, BLOCKED;
}
