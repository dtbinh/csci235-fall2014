package edu.hendrix.img;

public interface Processor {
	public IntImage process(IntImage input);
}
