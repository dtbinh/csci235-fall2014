package edu.hendrix.lmsl.unsupervised.gui;

import edu.hendrix.lmsl.unsupervised.controllers.Flag;

public interface FlagSwapListener {
	public void updatedFlag(Flag updated);
}
