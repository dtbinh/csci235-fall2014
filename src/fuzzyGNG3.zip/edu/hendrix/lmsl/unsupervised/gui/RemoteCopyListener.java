package edu.hendrix.lmsl.unsupervised.gui;

public interface RemoteCopyListener {
	public void complete(boolean success);
}
