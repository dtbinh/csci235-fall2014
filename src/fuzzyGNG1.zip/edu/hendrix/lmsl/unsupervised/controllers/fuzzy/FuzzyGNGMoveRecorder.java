package edu.hendrix.lmsl.unsupervised.controllers.fuzzy;

import java.io.IOException;
import java.util.LinkedHashMap;

import lejos.hardware.Button;
import lejos.hardware.Key;
import edu.hendrix.ev3webcam.GrabTossThread;
import edu.hendrix.ev3webcam.Webcam;
import edu.hendrix.img.IntImage;
import edu.hendrix.lmsl.EnumHistogram;
import edu.hendrix.lmsl.storage.Chooser;
import edu.hendrix.lmsl.storage.FuzzyGNGStorage;
import edu.hendrix.lmsl.storage.YesNoChooser;
import edu.hendrix.lmsl.unsupervised.controllers.AbstractGNGNodeMoves;
import edu.hendrix.lmsl.unsupervised.controllers.Flag;

public class FuzzyGNGMoveRecorder extends FuzzyGNGController {
	public static void main(String[] args) {
		new FuzzyGNGMoveRecorder().runController();
	}
	
	private LinkedHashMap<Key,Flag> key2Flag;
	
	protected AbstractGNGNodeMoves<EnumHistogram<Flag>, Flag> makeGNG() {
		Chooser<FuzzyGNGMoves<Flag>, FuzzyGNGStorage<Flag>> getOld = new Chooser<FuzzyGNGMoves<Flag>, FuzzyGNGStorage<Flag>>();
		FuzzyGNGStorage<Flag> storage = FuzzyGNGStorage.getEV3Storage(Flag.class);
		if (getOld.choicesExist(storage)) {
			YesNoChooser useOld = new YesNoChooser("Use existing GNG?", false);
			useOld.choose();
			if (useOld.isYes()) {
				getOld.choose(storage);
				if (getOld.isSelected()) {
					return getOld.getSelected();
				}
			}
		}
		
		return super.makeGNG();
	}
	
	public FuzzyGNGMoveRecorder() {
		super();
		key2Flag = new LinkedHashMap<Key,Flag>();		
		key2Flag.put(Button.UP, Flag.FORWARD);
		key2Flag.put(Button.DOWN, Flag.BACK);
		key2Flag.put(Button.LEFT, Flag.LEFT);
		key2Flag.put(Button.RIGHT, Flag.RIGHT);
		key2Flag.put(Button.ENTER, Flag.STOP);
		key2Flag.put(Button.ESCAPE, Flag.STOP);
	}

	public void runController() {
		try {
			try {
				Webcam.start(176, 144);
				//GrabTossThread grabber = new GrabTossThread();
				//grabber.start();
				Flag currentFlag = Flag.STOP;
				while (!Button.ESCAPE.isDown()) {
					//IntImage img = FuzzyGNGController.grabGNGImage(grabber);
					IntImage img = FuzzyGNGController.grabGNGImage(true);
					Key currentKey = getCurrentKey();
					Flag newFlag = key2Flag.containsKey(currentKey) ? key2Flag.get(currentKey) : currentFlag;
					if (currentFlag != newFlag) {
						performCurrentAction();
						currentFlag = newFlag;
					}
					if (currentFlag != Flag.STOP) {
						updateGNG(currentFlag, img);
					}
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			} finally {
				//grabber.halt();
				close();
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
			System.out.println("Driver exception: " + ioe.getMessage());
		} 
	}
}
