package edu.hendrix.lmsl.unsupervised.gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

import edu.hendrix.lmsl.unsupervised.controllers.AbstractGNGNodeMoves;
import edu.hendrix.lmsl.unsupervised.controllers.Flag;

@SuppressWarnings("serial")
public class GNGViewPanel<R,G extends AbstractGNGNodeMoves<R,Flag>> extends JPanel {
	private G gng;
	private ArrayList<Integer> nodeNums;
	private int currentNode;
	private GNGNodePanel nodePanel;
	private JTextField nodeField;
	
	public GNGViewPanel(G gng) {
		this.gng = gng;
		nodeNums = new ArrayList<Integer>(gng.getAllNodeNums());
		currentNode = 0;
		setLayout(new BorderLayout());
		JPanel top = new JPanel();
		JButton left = new JButton("Previous");
		left.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				resetCurrentNode(currentNode - 1);
			}});
		JButton right = new JButton("Next");
		right.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				resetCurrentNode(currentNode + 1);
			}});
		nodeField = new JTextField(4);
		nodeField.setEditable(false);
		top.add(left);
		top.add(nodeField);
		top.add(right);
		
		JPanel scale = new JPanel();
		JButton grow = new JButton("Grow");
		grow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				nodePanel.grow();
			}});
		
		JButton shrink = new JButton("Shrink");
		shrink.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				nodePanel.shrink();
			}});
		scale.add(grow);
		scale.add(shrink);
		
		JPanel buttons = new JPanel();
		buttons.setLayout(new GridLayout(2, 1));
		buttons.add(top);
		buttons.add(scale);
		
		add(buttons, BorderLayout.NORTH);
		nodePanel = new GNGNodePanel(gng.get(getNodeNum()), gng.getMoveFor(getNodeNum()));
		setNodeField();
		add(nodePanel, BorderLayout.CENTER);
	}
	
	public int getNodeNum() {return nodeNums.get(currentNode);}
	
	private void resetCurrentNode(int updatedIndex) {
		if (updatedIndex < 0) {updatedIndex = nodeNums.size() - 1;}
		if (updatedIndex >= nodeNums.size()) {updatedIndex = 0;}
		currentNode = updatedIndex;
		setNodeField();
		nodePanel.reset(gng.get(getNodeNum()), gng.getMoveFor(getNodeNum()));
		nodePanel.repaint();
	}
	
	private void setNodeField() {
		nodeField.setText(Integer.toString(getNodeNum()));
	}
}
