package edu.hendrix.lmsl.unsupervised.gui;

import java.io.FileNotFoundException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;

import edu.hendrix.lmsl.EnumHistogram;
import edu.hendrix.lmsl.storage.FuzzyGNGStorage;
import edu.hendrix.lmsl.unsupervised.controllers.Flag;
import edu.hendrix.lmsl.unsupervised.controllers.fuzzy.FuzzyGNGMoves;

@SuppressWarnings("serial")
public class GNGFuzzyViewFrame extends JFrame {
	public GNGFuzzyViewFrame() {
		super();
		setSize(400,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JTabbedPane allGNGs = new JTabbedPane();
		setContentPane(allGNGs);

		FuzzyGNGStorage<Flag> storage = FuzzyGNGStorage.getPCStorage(Flag.class);
		for (String choice: storage.choices()) {
			try {
				allGNGs.addTab(choice, new GNGViewPanel<EnumHistogram<Flag>,FuzzyGNGMoves<Flag>>(storage.open(choice)));
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog(this, "Could not open \"" + choice + "\"");
			}
		}
	}
	
	public static void main(String[] args) {
		new GNGFuzzyViewFrame().setVisible(true);
	}
}
