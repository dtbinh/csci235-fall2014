package edu.hendrix.lmsl.unsupervised.gui;

import java.io.FileNotFoundException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;

import edu.hendrix.lmsl.storage.GNGStorage;
import edu.hendrix.lmsl.unsupervised.controllers.Flag;

@SuppressWarnings("serial")
public class GNGViewFrame extends JFrame {
	public GNGViewFrame() {
		super();
		setSize(400,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JTabbedPane allGNGs = new JTabbedPane();
		setContentPane(allGNGs);

		GNGStorage<Flag> storage = GNGStorage.getPCStorage(Flag.class);
		for (String choice: storage.choices()) {
			try {
				allGNGs.addTab(choice, new GNGViewPanel(storage.open(choice)));
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog(this, "Could not open \"" + choice + "\"");
			}
		}
	}
	
	public static void main(String[] args) {
		new GNGViewFrame().setVisible(true);
	}
}
