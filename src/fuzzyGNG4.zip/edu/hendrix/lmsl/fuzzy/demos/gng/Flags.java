package edu.hendrix.lmsl.fuzzy.demos.gng;

public enum Flags {
	FORWARD, BACK, LEFT, RIGHT, STOP;
}
