package edu.hendrix.lmsl.demos.gngdemo;

public enum Flags {
	FORWARD, BACK, LEFT, RIGHT, STOP;
}
