package edu.hendrix.ev3webcam.demo;

import edu.hendrix.img.SimpleGradient;

public class EdgeDemo {
	public static void main(String[] args) {
		new ProcessorDemo(new SimpleGradient()).run();
	}
}
