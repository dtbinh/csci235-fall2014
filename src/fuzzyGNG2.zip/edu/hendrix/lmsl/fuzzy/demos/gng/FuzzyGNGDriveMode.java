package edu.hendrix.lmsl.fuzzy.demos.gng;

import java.io.IOException;

import lejos.hardware.motor.Motor;
import edu.hendrix.lmsl.FlagSet;
import edu.hendrix.lmsl.fuzzy.FuzzyMode;
import edu.hendrix.lmsl.fuzzy.FuzzyRule;

public class FuzzyGNGDriveMode extends FuzzyMode<Flags,ModeName> {

	public FuzzyGNGDriveMode() {
		super(Flags.class, ModeName.class);
		
		this.addRule(new FuzzyRule<Flags>(Motor.A, 0, 600) {
			@Override
			protected double inferFrom(FlagSet<Flags> flags) {
				return or(flags.getFuzzy(Flags.FORWARD), flags.getFuzzy(Flags.RIGHT));
			}});
		
		this.addRule(new FuzzyRule<Flags>(Motor.D, 0, 600) {
			@Override
			protected double inferFrom(FlagSet<Flags> flags) {
				return or(flags.getFuzzy(Flags.FORWARD), flags.getFuzzy(Flags.LEFT));
			}});		
	}
	
	public static void main(String[] args) throws IOException {
		new FuzzyGNGDriveMode().runController(new FuzzyGNGSensors(), ModeName.FUZZY_GNG);
	}
}
