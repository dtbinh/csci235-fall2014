package edu.hendrix.lmsl.fuzzy.demos.gng;

import java.io.IOException;

import edu.hendrix.lmsl.fuzzy.FuzzyFlagSet;
import edu.hendrix.lmsl.fuzzy.FuzzyFlagSetters;
import edu.hendrix.lmsl.unsupervised.controllers.fuzzy.FuzzyGNGFlagger;

public class FuzzyGNGSensors extends FuzzyFlagSetters<Flags> {

	public FuzzyGNGSensors() throws IOException {
		super(Flags.class);
		addFuzzySetter(new FuzzyGNGFlagger<Flags>(Flags.class));
	}

	@Override
	public FuzzyFlagSet<Flags> makeFlagSet() {
		return new FuzzyFlagSet<Flags>(Flags.class);
	}

}
