package edu.hendrix.lmsl.fuzzy.demos.demo2;

public enum FlagName {
	LEFT, RIGHT;
}
