package edu.hendrix.lmsl.demos.localize1;

public enum FlagName {
	PICK_FORWARD, PICK_LEFT, PICK_RIGHT, PICK_STOP;
}
