package edu.hendrix.lmsl;

public interface Action {
	public void begin();
	public void end();
}
