package edu.hendrix.lmsl.unsupervised.gui;

public class OSName {
	public static void main(String[] args) {
		System.out.println("OS:   " + System.getProperty("os.name"));
		System.out.println("User: " + System.getProperty("user.home"));
	}
}
