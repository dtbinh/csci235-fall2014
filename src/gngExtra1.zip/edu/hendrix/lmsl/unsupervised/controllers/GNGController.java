package edu.hendrix.lmsl.unsupervised.controllers;

import java.io.IOException;
import java.util.LinkedHashMap;

import lejos.hardware.Button;
import lejos.hardware.Key;
import lejos.hardware.lcd.LCD;
import lejos.hardware.motor.Motor;
import lejos.hardware.motor.NXTRegulatedMotor;
import edu.hendrix.ev3webcam.Webcam;
import edu.hendrix.ev3webcam.YUYVImage;
import edu.hendrix.img.IntImage;
import edu.hendrix.lmsl.Action;
import edu.hendrix.lmsl.storage.GNGStorage;

public class GNGController {

	private GNGNodeMoves<Flag> gng;
	private LinkedHashMap<Key,Action> key2Action;
	private NXTRegulatedMotor left = Motor.A;
	private NXTRegulatedMotor right = Motor.D;
	private boolean gngChanged;

	public GNGController() {
		gng = makeGNG();
		gngChanged = false;
		
		key2Action = new LinkedHashMap<Key,Action>();
		key2Action.put(Button.UP, new Up());
		key2Action.put(Button.DOWN, new Down());
		key2Action.put(Button.LEFT, new Left());
		key2Action.put(Button.RIGHT, new Right());
		key2Action.put(Button.ENTER, new Stopper());
		key2Action.put(Button.ESCAPE, new Stopper());
	}
	
	protected GNGNodeMoves<Flag> makeGNG() {
		return new GNGNodeMoves<Flag>(2, 40);
	}
	
	public boolean hasGNG() {return gng != null;}
	
	public void stopRobot() {
		key2Action.get(Button.ESCAPE).begin();
	}

	public Key getCurrentKey() {
		for (Key key: key2Action.keySet()) {
			if (key.isDown()) {return key;}
		}
		return null;
	}

	public void performCurrentAction(Key key) {
		if (key != null) {key2Action.get(key).begin();}
	}
	
	public void performCurrentAction() {
		performCurrentAction(getCurrentKey());
	}
	
	public void close() throws IOException {
		stopRobot();

		double fps = Webcam.end();
		LCD.clear();
		System.out.println(String.format("%4.2f", fps) + " fps");	
		if (gngChanged) {saveGNG();}
		while (!Button.ESCAPE.isDown());
	}
	
	public void updateGNG(Flag currentFlag, IntImage img) {
		gng.update(currentFlag, img);
		gngChanged = true;
	}
	
	public int getNodeFor(IntImage img) {
		return gng.getNodeFor(img);
	}
	
	public Flag getFlagFor(int node) {
		return gng.getMoveFor(node);
	}
	
	public IntImage getImageFor(int node) {
		return gng.get(node);
	}
	
	public void saveGNG() throws IOException {
		System.out.println(gng.numNodes() + " nodes");
		GNGStorage.getEV3Storage(Flag.class).save(gng);
	}
	
	public static IntImage grabGNGImage(boolean displayImage) throws IOException {
		YUYVImage grabbed = YUYVImage.grab();
		if (displayImage) {grabbed.displayLCD();}
		return IntImage.toShrunkenGrayInts(grabbed, 4);
	}

	abstract private class MyAction implements Action {
		private int speed;
		public MyAction(int speed) {this.speed = speed;}
		public void setSpeed() {
			left.setSpeed(speed);
			right.setSpeed(speed);
		}
		
		public void end() {}
	}
	
	private class Up extends MyAction {
		public Up() {
			super(360);
		}

		@Override
		public void begin() {
			setSpeed();
			left.forward();
			right.forward();
		}
	}
	
	private class Down extends MyAction {
		public Down() {
			super(360);
		}

		@Override
		public void begin() {
			setSpeed();
			left.backward();
			right.backward();
		}
	}
	
	private class Left extends MyAction {
		public Left() {
			super(120);
		}

		@Override
		public void begin() {
			setSpeed();
			left.backward();
			right.forward();
		}
	}
	
	private class Right extends MyAction {
		public Right() {
			super(120);
		}

		@Override
		public void begin() {
			setSpeed();
			left.forward();
			right.backward();
		}
	}
	
	private class Stopper implements Action {
		@Override
		public void begin() {
			left.stop(true);
			right.stop();
		}

		@Override
		public void end() {}
	}
}