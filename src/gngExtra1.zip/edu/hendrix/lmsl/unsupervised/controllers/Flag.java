package edu.hendrix.lmsl.unsupervised.controllers;

public enum Flag {
	FORWARD, LEFT, RIGHT, BACK, STOP;
}
