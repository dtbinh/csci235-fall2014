package edu.hendrix.lmsl.unsupervised.controllers;

import java.io.IOException;
import java.util.LinkedHashMap;

import lejos.hardware.Button;
import lejos.hardware.Key;
import lejos.hardware.lcd.LCD;
import lejos.hardware.motor.Motor;
import lejos.hardware.motor.NXTRegulatedMotor;
import edu.hendrix.ev3webcam.Webcam;
import edu.hendrix.ev3webcam.YUYVImage;
import edu.hendrix.img.IntImage;
import edu.hendrix.lmsl.Action;
import edu.hendrix.lmsl.storage.GNGStorage;

public class GNGMoveRecorder {
	public static void main(String[] args) {
		new GNGMoveRecorder().runController();
	}
	
	private GNGNodeMoves<Flag> gng;
	private LinkedHashMap<Key,Flag> key2Flag;
	private LinkedHashMap<Key,Action> key2Action;
	
	public GNGMoveRecorder() {
		gng = new GNGNodeMoves<Flag>(2, 40);
		key2Flag = new LinkedHashMap<Key,Flag>();
		key2Action = new LinkedHashMap<Key,Action>();
		key2Action.put(Button.UP, new Up());
		key2Action.put(Button.DOWN, new Down());
		key2Action.put(Button.LEFT, new Left());
		key2Action.put(Button.RIGHT, new Right());
		key2Action.put(Button.ENTER, new Stopper());
		key2Action.put(Button.ESCAPE, new Stopper());
		
		key2Flag.put(Button.UP, Flag.FORWARD);
		key2Flag.put(Button.DOWN, Flag.BACK);
		key2Flag.put(Button.LEFT, Flag.LEFT);
		key2Flag.put(Button.RIGHT, Flag.RIGHT);
		key2Flag.put(Button.ENTER, Flag.STOP);
		key2Flag.put(Button.ESCAPE, Flag.STOP);
	}
	
	public Key getCurrentKey() {
		for (Key key: key2Action.keySet()) {
			if (key.isDown()) {return key;}
		}
		return null;
	}
	
	public static IntImage grabGNGImage() throws IOException {
		YUYVImage grabbed = YUYVImage.grab();
		grabbed.displayLCD();
		return IntImage.toShrunkenGrayInts(grabbed, 4);
	}
	
	public void runController() {
		try {
			Webcam.start(176, 144);
			Flag previous = Flag.STOP;
			while (!Button.ESCAPE.isDown()) {
				IntImage img = grabGNGImage();
				Key currentKey = getCurrentKey();
				if (currentKey != null) {
					Flag currentFlag = key2Flag.containsKey(currentKey) ? key2Flag.get(currentKey) : previous;
					if (currentFlag != Flag.STOP) {
						gng.update(currentFlag, img);
					}
					key2Action.get(currentKey).begin();
					previous = currentFlag;
				}
			}
			
			left.stop(true);
			right.stop();

			double fps = Webcam.end();
			LCD.clear();
			System.out.println(fps + " fps");	
			System.out.println(gng.numNodes() + " nodes");
			GNGStorage.getEV3Storage(Flag.class).save(gng);
			while (!Button.ESCAPE.isDown());
		} catch (IOException ioe) {
			ioe.printStackTrace();
			System.out.println("Driver exception: " + ioe.getMessage());
		}
	}
	
	private NXTRegulatedMotor left = Motor.A;
	private NXTRegulatedMotor right = Motor.D;
	
	abstract private class MyAction implements Action {
		private int speed;
		public MyAction(int speed) {this.speed = speed;}
		public void setSpeed() {
			left.setSpeed(speed);
			right.setSpeed(speed);
		}
		
		public void end() {}
	}
	
	private class Up extends MyAction {
		public Up() {
			super(360);
		}

		@Override
		public void begin() {
			setSpeed();
			left.forward();
			right.forward();
		}
	}
	
	private class Down extends MyAction {
		public Down() {
			super(360);
		}

		@Override
		public void begin() {
			setSpeed();
			left.backward();
			right.backward();
		}
	}
	
	private class Left extends MyAction {
		public Left() {
			super(120);
		}

		@Override
		public void begin() {
			setSpeed();
			left.backward();
			right.forward();
		}
	}
	
	private class Right extends MyAction {
		public Right() {
			super(120);
		}

		@Override
		public void begin() {
			setSpeed();
			left.forward();
			right.backward();
		}
	}
	
	private class Stopper implements Action {
		@Override
		public void begin() {
			left.stop(true);
			right.stop();
		}

		@Override
		public void end() {}
	}
}
